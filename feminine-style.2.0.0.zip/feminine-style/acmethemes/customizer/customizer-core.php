<?php
/**
 * Header Image Display Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_menu_display_options
 *
 */
if ( !function_exists('feminine_style_menu_display_options') ) :
	function feminine_style_menu_display_options() {
		$feminine_style_menu_display_options =  array(
			'header-default'      => esc_html__( 'Default', 'feminine-style' ),
			'menu-classic'      => esc_html__( 'Classic', 'feminine-style' ),
		);
		return apply_filters( 'feminine_style_menu_display_options', $feminine_style_menu_display_options );
	}
endif;

/**
 * Menu and Logo Display Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_header_image_display
 *
 */
if ( !function_exists('feminine_style_header_image_display') ) :
	function feminine_style_header_image_display() {
		$feminine_style_header_image_display =  array(
			'hide'              => esc_html__( 'Hide', 'feminine-style' ),
			'bg-image'          => esc_html__( 'Background Image', 'feminine-style' ),
			'normal-image'      => esc_html__( 'Normal Image', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_header_image_display', $feminine_style_header_image_display );
	}
endif;

/**
 * Menu Right Button Link Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_menu_right_button_link_options
 *
 */
if ( !function_exists('feminine_style_menu_right_button_link_options') ) :
	function feminine_style_menu_right_button_link_options() {
		$feminine_style_menu_right_button_link_options =  array(
			'disable'       => esc_html__( 'Disable', 'feminine-style' ),
			'booking'       => esc_html__( 'Popup Widgets ( Booking Form )', 'feminine-style' ),
			'link'          => esc_html__( 'One Link', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_menu_right_button_link_options', $feminine_style_menu_right_button_link_options );
	}
endif;

/**
 * Header top display options of elements
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_header_top_display_selection
 *
 */
if ( !function_exists('feminine_style_header_top_display_selection') ) :
	function feminine_style_header_top_display_selection() {
		$feminine_style_header_top_display_selection =  array(
			'hide'          => esc_html__( 'Hide', 'feminine-style' ),
			'left'          => esc_html__( 'on Top Left', 'feminine-style' ),
			'right'         => esc_html__( 'on Top Right', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_header_top_display_selection', $feminine_style_header_top_display_selection );
	}
endif;

/**
 * Feature slider text align
 *
 * @since Mercantile 1.0.0
 *
 * @param null
 * @return array $feminine_style_slider_text_align
 *
 */
if ( !function_exists('feminine_style_slider_text_align') ) :
	function feminine_style_slider_text_align() {
		$feminine_style_slider_text_align =  array(
			'alternate'     => esc_html__( 'Alternate', 'feminine-style' ),
			'text-left'     => esc_html__( 'Left', 'feminine-style' ),
			'text-right'    => esc_html__( 'Right', 'feminine-style' ),
			'text-center'   => esc_html__( 'Center', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_slider_text_align', $feminine_style_slider_text_align );
	}
endif;

/**
 * Featured Slider Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_fs_display_options
 *
 */
if ( !function_exists('feminine_style_fs_display_options') ) :
	function feminine_style_fs_display_options() {
		$feminine_style_fs_image_display_options =  array(
			'at-feature-banner' => esc_html__( 'Feature Banner', 'feminine-style' ),
			'at-normal-banner' => esc_html__( 'Normal Banner', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_fs_display_options', $feminine_style_fs_image_display_options );
	}
endif;

/**
 * Featured Slider Image Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_fs_image_display_options
 *
 */
if ( !function_exists('feminine_style_fs_image_display_options') ) :
	function feminine_style_fs_image_display_options() {
		$feminine_style_fs_image_display_options =  array(
			'full-screen-bg' => esc_html__( 'Full Screen Background', 'feminine-style' ),
			'responsive-img' => esc_html__( 'Responsive Image', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_fs_image_display_options', $feminine_style_fs_image_display_options );
	}
endif;

/**
 * Feature Info number
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_feature_info_number
 *
 */
if ( !function_exists('feminine_style_feature_info_number') ) :
	function feminine_style_feature_info_number() {
		$feminine_style_feature_info_number =  array(
			1               => esc_html__( '1', 'feminine-style' ),
			2               => esc_html__( '2', 'feminine-style' ),
			3               => esc_html__( '3', 'feminine-style' ),
			4               => esc_html__( '4', 'feminine-style' ),
		);
		return apply_filters( 'feminine_style_feature_info_number', $feminine_style_feature_info_number );
	}
endif;

/**
 * Footer copyright beside options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_footer_copyright_beside_option
 *
 */
if ( !function_exists('feminine_style_footer_copyright_beside_option') ) :
	function feminine_style_footer_copyright_beside_option() {
		$feminine_style_footer_copyright_beside_option =  array(
			'hide'          => esc_html__( 'Hide', 'feminine-style' ),
			'social'        => esc_html__( 'Social Links', 'feminine-style' ),
			'footer-menu'   => esc_html__( 'Footer Menu', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_footer_copyright_beside_option', $feminine_style_footer_copyright_beside_option );
	}
endif;

/**
 * Button design options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_button_design
 *
 */
if ( !function_exists('feminine_style_button_design') ) :
	function feminine_style_button_design() {
		$feminine_style_button_design =  array(
			'rectangle'         => esc_html__( 'Rectangle', 'feminine-style' ),
			'rounded-rectangle' => esc_html__( 'Rounded Rectangle', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_button_design', $feminine_style_button_design );
	}
endif;

/**
 * Sidebar layout options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_sidebar_layout
 *
 */
if ( !function_exists('feminine_style_sidebar_layout') ) :
    function feminine_style_sidebar_layout() {
        $feminine_style_sidebar_layout =  array(
	        'right-sidebar' => esc_html__( 'Right Sidebar', 'feminine-style' ),
	        'left-sidebar'  => esc_html__( 'Left Sidebar' , 'feminine-style' ),
	        'both-sidebar'  => esc_html__( 'Both Sidebar' , 'feminine-style' ),
	        'middle-col'    => esc_html__( 'Middle Column' , 'feminine-style' ),
	        'no-sidebar'    => esc_html__( 'No Sidebar', 'feminine-style' )
        );
        return apply_filters( 'feminine_style_sidebar_layout', $feminine_style_sidebar_layout );
    }
endif;

/**
 * Blog layout options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_blog_archive_feature_layout
 *
 */
if ( !function_exists('feminine_style_blog_archive_feature_layout') ) :
    function feminine_style_blog_archive_feature_layout() {
        $feminine_style_blog_archive_feature_layout =  array(
            'left-image'    => esc_html__( 'Show Image', 'feminine-style' ),
            'no-image'      => esc_html__( 'No Image', 'feminine-style' )
        );
        return apply_filters( 'feminine_style_blog_archive_feature_layout', $feminine_style_blog_archive_feature_layout );
    }
endif;

/**
 * Blog content from
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_blog_archive_content_from
 *
 */
if ( !function_exists('feminine_style_blog_archive_content_from') ) :
	function feminine_style_blog_archive_content_from() {
		$feminine_style_blog_archive_content_from =  array(
			'excerpt'    => esc_html__( 'Excerpt', 'feminine-style' ),
			'content'    => esc_html__( 'Content', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_blog_archive_content_from', $feminine_style_blog_archive_content_from );
	}
endif;

/**
 * Image Size
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_get_image_sizes_options
 *
 */
if ( !function_exists('feminine_style_get_image_sizes_options') ) :
	function feminine_style_get_image_sizes_options( $add_disable = false ) {
		global $_wp_additional_image_sizes;
		$choices = array();
		if ( true == $add_disable ) {
			$choices['disable'] = esc_html__( 'No Image', 'feminine-style' );
		}
		foreach ( array( 'thumbnail', 'medium', 'large' ) as $key => $_size ) {
			$choices[ $_size ] = $_size . ' ('. get_option( $_size . '_size_w' ) . 'x' . get_option( $_size . '_size_h' ) . ')';
		}
		$choices['full'] = esc_html__( 'full (original)', 'feminine-style' );
		if ( ! empty( $_wp_additional_image_sizes ) && is_array( $_wp_additional_image_sizes ) ) {

			foreach ($_wp_additional_image_sizes as $key => $size ) {
				$choices[ $key ] = $key . ' ('. $size['width'] . 'x' . $size['height'] . ')';
			}
		}
		return apply_filters( 'feminine_style_get_image_sizes_options', $choices );
	}
endif;

/**
 * Pagination Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array feminine_style_pagination_options
 *
 */
if ( !function_exists('feminine_style_pagination_options') ) :
	function feminine_style_pagination_options() {
		$feminine_style_pagination_options =  array(
			'default'  => esc_html__( 'Default', 'feminine-style' ),
			'numeric'  => esc_html__( 'Numeric', 'feminine-style' )
		);
		return apply_filters( 'feminine_style_pagination_options', $feminine_style_pagination_options );
	}
endif;

/**
 * Breadcrumb Options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array feminine_style_breadcrumb_options
 *
 */
if ( !function_exists('feminine_style_breadcrumb_options') ) :
	function feminine_style_breadcrumb_options() {
		$feminine_style_breadcrumb_options =  array(
			'hide'  => esc_html__( 'Hide', 'feminine-style' ),
		);
		if ( function_exists('yoast_breadcrumb') ) {
			$feminine_style_breadcrumb_options['yoast'] = esc_html__( 'Yoast', 'feminine-style' );
		}
		if ( function_exists('bcn_display') ) {
			$feminine_style_breadcrumb_options['bcn'] = esc_html__( 'Breadcrumb NavXT', 'feminine-style' );
		}
		return apply_filters( 'feminine_style_pagination_options', $feminine_style_breadcrumb_options );
	}
endif;

/**
 * Default Theme layout options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array $feminine_style_theme_layout
 *
 */
if ( !function_exists('feminine_style_get_default_theme_options') ) :
    function feminine_style_get_default_theme_options() {

        $default_theme_options = array(

	        /*logo and site title*/
	        'feminine-style-display-site-logo'      => '',
	        'feminine-style-display-site-title'     => 1,
	        'feminine-style-display-site-tagline'   => 1,

	        /*header height*/
	        'feminine-style-header-height'          => 300,
	        'feminine-style-header-image-display'   => 'normal-image',

            /*header top*/
            'feminine-style-enable-header-top'       => '',
	        'feminine-style-header-top-menu-display-selection'      => 'right',
	        'feminine-style-header-top-info-display-selection'      => 'left',
	        'feminine-style-header-top-social-display-selection'    => 'right',

	        /*menu options*/
            'feminine-style-menu-display-options'      => 'header-default',
            'feminine-style-enable-sticky'                  => '',
	        'feminine-style-menu-right-button-options'      => 'disable',
	        'feminine-style-menu-right-button-title'        => esc_html__('View More','feminine-style'),
	        'feminine-style-menu-right-button-link'         => '',
            'feminine-style-enable-cart-icon'               => '',

	        /*feature section options*/
	        'feminine-style-enable-feature'                         => '',
	        'feminine-style-slides-data'                            => '',
            'feminine-style-feature-slider-enable-animation'        => 1,
            'feminine-style-feature-slider-display-title'           => 1,
            'feminine-style-feature-slider-display-excerpt'         => 1,
            'feminine-style-fs-display-options'               		=> 'at-feature-banner',
            'feminine-style-fs-image-display-options'               => 'full-screen-bg',
            'feminine-style-feature-slider-text-align'              => 'text-left',
            'feminine-style-slider-scroll-text'              => '',
            'feminine-style-slider-scroll-link'              => '',

	        /*basic info*/
	        'feminine-style-feature-info-number'    => 4,
	        'feminine-style-first-info-icon'        => 'fas fa-calendar',
	        'feminine-style-first-info-title'       => esc_html__('Send Us a Mail', 'feminine-style'),
	        'feminine-style-first-info-desc'        => esc_html__('domain@example.com ', 'feminine-style'),
	        'feminine-style-second-info-icon'       => 'fas fa-map-marker',
	        'feminine-style-second-info-title'      => esc_html__('Our Location', 'feminine-style'),
	        'feminine-style-second-info-desc'       => esc_html__('Elmonte California', 'feminine-style'),
	        'feminine-style-third-info-icon'        => 'fas fa-phone',
	        'feminine-style-third-info-title'       => esc_html__('Call Us', 'feminine-style'),
	        'feminine-style-third-info-desc'        => esc_html__('01-23456789-10', 'feminine-style'),
	        'feminine-style-forth-info-icon'        => 'fas fa-envelope-o',
	        'feminine-style-forth-info-title'       => esc_html__('Office Hours', 'feminine-style'),
	        'feminine-style-forth-info-desc'        => esc_html__('8 hours per day', 'feminine-style'),

            /*footer options*/
            'feminine-style-footer-copyright'                       => esc_html__( '&copy; All right reserved', 'feminine-style' ),
	        'feminine-style-footer-copyright-beside-option'         => 'footer-menu',
	        'feminine-style-enable-footer-power-text'               => 1,
	        'feminine-style-footer-site-info'                       => '',
	        'feminine-style-footer-bg-img'                          => '',


	        /*layout/design options*/
	        'feminine-style-pagination-option'      => 'numeric',

	        'feminine-style-enable-animation'       => '',

	        'feminine-style-single-sidebar-layout'                  => 'right-sidebar',
            'feminine-style-front-page-sidebar-layout'              => 'right-sidebar',
            'feminine-style-archive-sidebar-layout'                 => 'right-sidebar',

            'feminine-style-blog-archive-img-size'                  => 'full',
            'feminine-style-blog-archive-content-from'              => 'excerpt',
            'feminine-style-blog-archive-excerpt-length'            => 42,
	        'feminine-style-blog-archive-more-text'                 => esc_html__( 'Read More', 'feminine-style' ),


	        'feminine-style-primary-color'          => '#E590B5',
            'feminine-style-header-top-bg-color'    => '#323232',
            'feminine-style-footer-bg-color'        => '#323232',
            'feminine-style-footer-bottom-bg-color' => '',
            'feminine-style-link-color'             => '#E590B5',
            'feminine-style-link-hover-color'       => '#D580A5',

	        'feminine-style-hide-front-page-content' => '',
	        'feminine-style-hide-front-page-header'  => '',

	        /*woocommerce*/
	        'feminine-style-wc-shop-archive-sidebar-layout'     => 'no-sidebar',
	        'feminine-style-wc-product-column-number'           => 4,
	        'feminine-style-wc-shop-archive-total-product'      => 16,
	        'feminine-style-wc-single-product-sidebar-layout'   => 'no-sidebar',

	        /*single post*/
	        'feminine-style-single-header-title'            => esc_html__( 'Blog', 'feminine-style' ),
	        'feminine-style-single-img-size'                => 'full',

	        /*theme options*/
            'feminine-style-popup-widget-title'     => esc_html__( 'Booking Table', 'feminine-style' ),
	        'feminine-style-breadcrumb-options'        => 'hide',
            'feminine-style-search-placeholder'     => esc_html__( 'Search', 'feminine-style' ),
            'feminine-style-social-data'            => '',

        );
        return apply_filters( 'feminine_style_default_theme_options', $default_theme_options );
    }
endif;

/**
 * Get theme options
 *
 * @since Feminine Style 1.0.0
 *
 * @param null
 * @return array feminine_style_theme_options
 *
 */
if ( !function_exists('feminine_style_get_theme_options') ) :
    function feminine_style_get_theme_options() {

        $feminine_style_default_theme_options = feminine_style_get_default_theme_options();
        $feminine_style_get_theme_options = get_theme_mod( 'feminine_style_theme_options');
        if( is_array( $feminine_style_get_theme_options )){
            return array_merge( $feminine_style_default_theme_options ,$feminine_style_get_theme_options );
        }
        else{
            return $feminine_style_default_theme_options;
        }
    }
endif;