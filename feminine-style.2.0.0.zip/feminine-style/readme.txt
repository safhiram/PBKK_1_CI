=== Feminine Style ===

Contributors: acmethemes
Tags: blog, e-commerce, portfolio, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, full-width-template ,post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready, wide-blocks
Requires at least: 4.8
Tested up to: 5.2.4
Requires PHP: 5.6.20
Stable tag: 2.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Feminine Style is a complete feminine based WordPress theme.

== Description ==

Feminine Style is a voguish, dazzling and very appealing WordPress theme. The theme is completely woman based and made for modern women around the world to have their personal or professional online presence. The entire look of the theme has been designed in a stylish way that it reflects feminism. The awesome powerful and advanced features of the theme makes it more flexible and worthy. It is extremely responsive and adapts well to all modern electronic devices like smartphones and tablets. The customization of the theme is a very simple and easy task to perform. You can just go to its customizer option settings and change its header, footer, sidebar, slider and other section of the theme cosily. Enhance the appearance of the theme by adding more beautiful accessible widgets. You can also make your site even flexible by extending its functionalities by adding various kinds of popular plugins. Work with all popular page builders as Elementor, Beaver Builder, SiteOrigin, etc. Compatible with Woocommerce and almost all popular plugins.

== Frequently Asked Questions ==

= How to Install Theme =

1. In your admin panel, go to Appearance > Themes and click the Add New button and Search for Feminine, OR
2. If you have the theme zip file, click Upload and choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

= Front Page/Home page Customization ==

1. In the admin area, go to Pages > Add New
2. Again In the admin area, go to Settings > Reading
3. In Frontpage displays choose 'A static page (select below)' and select page for homepage/frontpage
4. The sidebar "Home Main Content Area" will display on the homepage

= How to change content or customize site? =
1. In the admin area, go to Appearance > Customize
2. You will find different options in customizer
3. Add/Edit Widgets, Page and Post

== Change log ==

= 2.0.0 - Oct 17 2019=
* Added : wp_body_open hook in header
* Added : Gutentor Plugin in TGM
* Added : wp-config.xml file for translation
* Added : Upgrade to pro

= 1.0.0 =
* Submitted on WordPress dot org

== Copyright ==

Feminine Style WordPress Theme, Copyright 2016-2019 Acme Themes( acmethemes.com )
Feminine Style is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Feminine Style bundles the following third-party resources:

* Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License Version 2 or later.
* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Google Fonts - Apache License, version 2.0
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* Bootstrap http://getbootstrap.com/ [MIT](http://opensource.org/licenses/MIT) Copyright 2011-2015 Twitter, Inc.
* Font-Awesome https://github.com/FortAwesome/Font-Awesome , Font: SIL OFL 1.1, CSS: MIT License by @davegandy
* html5shiv https://github.com/afarkas/html5shiv [MIT](http://opensource.org/licenses/MIT) by @afarkas @jdalton @jon_neal @rem
* Isotope PACKAGED http://isotope.metafizzy.co GPLv3 Copyright 2017 Metafizzy
* Magnific Popup https://github.com/dimsemenov/Magnific-Popup [MIT](https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSE)
* respond.min https://github.com/scottjehl/Respond [MIT](http://opensource.org/licenses/MIT) Copyright Scott Jehl
* Slick https://github.com/kenwheeler/slick/ [MIT](http://opensource.org/licenses/MIT) Copyright (c) 2014 Ken Wheeler
* WOW https://github.com/matthieua/WOW [MIT](http://opensource.org/licenses/MIT) Copyright (c) 2013 Daniel Eden
* TGM-Plugin-Activation Copyright 2011 Thomas Griffin (thomas licensed under the GNU GPL

== Screenshots ==

* https://pxhere.com/en/photo/527819 - License CC0 Public Domain
* https://pxhere.com/en/photo/1209975 - License CC0 Public Domain
* feminine-style-inner-banner1920x600.jpg *https://pxhere.com/en/photo/1153932 - License CC0 Public Domain
* default-image.jpg, 404-image.png : Self Created - License CC0 Public Domain