<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Acme Themes
 * @subpackage Feminine Style
 */
get_header();
global $feminine_style_customizer_all_values;
?>
<div class="wrapper inner-main-title">
	<?php
	echo feminine_style_get_header_normal_image();
	?>
	<div class="container">
		<header class="entry-header init-animate">
			<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'feminine-style' ); ?></h1>
			<?php
			feminine_style_breadcrumbs();
			?>
		</header>
	</div>
</div>
<div id="content" class="site-content container clearfix">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<section class="error-404 not-found">
				<div class="page-content">
					<div class="row">
						<div class="col-md-12">
						
							<div class="error-content">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/404-image.png" alt="<?php esc_attr_e('404 image','feminine-style')?>" />

								<h1><?php esc_html_e('404 Error','feminine-style'); ?></h1>
								<h3>
									<?php esc_html_e('Sorry! We could not found that page','feminine-style'); ?>
								</h3>
								<p>
								<?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'feminine-style' ); ?>

								</p>
								<?php get_search_form(); ?>
							</div>
						</div>
					</div>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->
		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- #content -->
<?php get_footer();